create
    definer = test_cps_user@`%` procedure a()
BEGIN
declare i int;
set i = 0;
while i < 5 do
	INSERT custom_media(admin_id,message_text,message_type) VALUES(3,'[{"cost": "110", "push": "0", "type": "0", "title": "文字Title", "book_id": "11000000027", "wx_type": "1", "book_name": "媚后惑天下", "channel_name": "qd01", "guide_chapter_idx": "10"}]', 1);
	set i = i + 1;
end WHILE;

end;

