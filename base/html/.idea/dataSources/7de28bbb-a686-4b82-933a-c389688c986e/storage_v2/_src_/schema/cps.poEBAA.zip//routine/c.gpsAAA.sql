create
    definer = test_cps_user@`%` procedure c()
BEGIN
declare i int;
set i = 0;
while i < 30 do
	INSERT custom(title, admin_id, message_json,sendtime,user_json,statue,message_text,message_type)
VALUES('文字链客服消息01', 3, '[]',1539313155,'[]','normal','文字Title',1);
	set i = i + 1;
end WHILE;

end;

